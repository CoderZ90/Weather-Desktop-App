const { app, BrowserWindow } = require('electron');
// it says that when our app is ready create a window
app.whenReady().then(createWindow);

function createWindow() {
    const win = new BrowserWindow({
        // here adjust the width and height according to your need you can crease and descrease it if you want to
        width: 500,
        height: 700,
        // resizable makes the app to resize ( we can adjust the heigth and width )
        resizable: true,
        autoHideMenuBar: true
        // before this lets adjust the width and heigth properly
    })
    // it will load file index.html so lets create it
    win.loadFile("index.html");
}